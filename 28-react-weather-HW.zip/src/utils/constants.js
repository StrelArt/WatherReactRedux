export const base_url = 'https://api.openweathermap.org/data/2.5/weather';
export const api_key = '31f99b262592f512e6a7b53896f003c5';